package com.example.android.s55986_labtest_1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText

class PhoneNumber : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_phone_number)

        val sp = this.getSharedPreferences("ahmad", MODE_PRIVATE)

        val iphone = findViewById<EditText>(R.id.inputPhone)

        iphone.setText(sp.getString("phone", null))

    }

    override fun onPause() {
        super.onPause()
        val iphone = findViewById<EditText>(R.id.inputPhone)


        val sp = this.getSharedPreferences("ahmad", MODE_PRIVATE)
        val editor = sp.edit()
        editor.putString("phone",iphone.text.toString())

        editor.commit()


    }
}